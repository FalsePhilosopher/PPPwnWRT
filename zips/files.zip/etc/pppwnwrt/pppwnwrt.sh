#!/bin/sh
while true; do
    pppwn -i changeme --fw changeme -s1 /etc/pppwnwrt/stage1.bin -s2 /etc/pppwnwrt/stage2.bin -a
    sleep 30
done

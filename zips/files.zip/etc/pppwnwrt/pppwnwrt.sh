#!/bin/sh
while true; do
    pppwn -i INTERFACE --fw FIRMWAREVER -s1 /etc/pppwnwrt/stage1_FIRMWAREVER.bin -s2 /etc/pppwnwrt/stage2.bin -a
    sleep 60
done
